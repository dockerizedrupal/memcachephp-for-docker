# memcache.php

An APC-like stats/info page for your memcached servers.

**THIS IS A WORK IN PROGRESS**

## Requirements

 * Twitter Bootstrap 2.0.2

## Setup

 * git clone this
 * make changes to `etc/config.local.php` (copy from `etc/config.php`)
 * Profit!

## Credit

 * [Harun Yayli](http://livebookmark.net/journal/2008/05/21/memcachephp-stats-like-apcphp/)
 * [Arthur Ejsmont](http://artur.ejsmont.org/blog/content/first-version-of-memcache-stats-script-based-on-memcachephp)
